import json
import logging
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import AuditLog


logger = logging.getLogger(__name__)


class AuditService:
    @staticmethod
    async def log_event(
        db: AsyncSession,
        action: str,
        actor_type: str,
        actor_id: uuid.UUID | None,
        target_type: str,
        target_id: uuid.UUID | None,
        tenant_id: uuid.UUID | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        payload = json.dumps(details, ensure_ascii=True) if details else None
        try:
            async with db.begin_nested():
                record = AuditLog(
                    action=action,
                    actor_type=actor_type,
                    actor_id=actor_id,
                    target_type=target_type,
                    target_id=target_id,
                    tenant_id=tenant_id,
                    details_json=payload,
                )
                db.add(record)
                await db.flush()
        except Exception:
            logger.exception("Audit logging failed", extra={"action": action})
