from __future__ import annotations

import uuid
from datetime import datetime

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.crm import CRMAppointment, CRMClientFile, CRMProfessional, CRMVisitReport

CRM_ALLOWED_SUBJECT_KINDS = {"patient", "client", "case", "company", "lead"}
CRM_ALLOWED_APPOINTMENT_STATUSES = {"scheduled", "confirmed", "completed", "cancelled", "no_show"}
CRM_ALLOWED_SOURCES = {"internal", "self_service"}


class CRMService:
    @staticmethod
    def normalize_subject_kind(subject_kind: str | None) -> str:
        normalized = (subject_kind or "client").strip().lower()
        return normalized if normalized in CRM_ALLOWED_SUBJECT_KINDS else "client"

    @staticmethod
    def normalize_appointment_status(status_value: str | None) -> str:
        normalized = (status_value or "scheduled").strip().lower()
        return normalized if normalized in CRM_ALLOWED_APPOINTMENT_STATUSES else "scheduled"

    @staticmethod
    def normalize_source(source_value: str | None) -> str:
        normalized = (source_value or "internal").strip().lower()
        return normalized if normalized in CRM_ALLOWED_SOURCES else "internal"

    @staticmethod
    async def get_professional_or_404(
        db: AsyncSession,
        tenant_id: uuid.UUID,
        professional_id: uuid.UUID,
    ) -> CRMProfessional:
        professional = await db.get(CRMProfessional, professional_id)
        if not professional or professional.tenant_id != tenant_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Profesional no encontrado")
        return professional

    @staticmethod
    async def get_client_file_or_404(
        db: AsyncSession,
        tenant_id: uuid.UUID,
        file_id: uuid.UUID,
    ) -> CRMClientFile:
        client_file = await db.get(CRMClientFile, file_id)
        if not client_file or client_file.tenant_id != tenant_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Expediente no encontrado")
        return client_file

    @staticmethod
    async def get_appointment_or_404(
        db: AsyncSession,
        tenant_id: uuid.UUID,
        appointment_id: uuid.UUID,
    ) -> CRMAppointment:
        appointment = await db.get(CRMAppointment, appointment_id)
        if not appointment or appointment.tenant_id != tenant_id:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Turno no encontrado")
        return appointment

    @staticmethod
    def serialize_professional(professional: CRMProfessional) -> dict:
        return {
            "id": str(professional.id),
            "name": professional.name,
            "role_label": professional.role_label,
            "specialty": professional.specialty,
            "calendar_color": professional.calendar_color,
            "active": professional.active,
            "extra_data": professional.extra_data or {},
            "created_at": professional.created_at.isoformat() if professional.created_at else None,
            "updated_at": professional.updated_at.isoformat() if professional.updated_at else None,
        }

    @staticmethod
    def serialize_client_file(client_file: CRMClientFile) -> dict:
        return {
            "id": str(client_file.id),
            "subject_kind": client_file.subject_kind,
            "display_name": client_file.display_name,
            "reference_code": client_file.reference_code,
            "document_id": client_file.document_id,
            "email": client_file.email,
            "phone": client_file.phone,
            "status": client_file.status,
            "notes": client_file.notes,
            "extra_data": client_file.extra_data or {},
            "created_at": client_file.created_at.isoformat() if client_file.created_at else None,
            "updated_at": client_file.updated_at.isoformat() if client_file.updated_at else None,
        }

    @staticmethod
    def serialize_appointment(appointment: CRMAppointment) -> dict:
        return {
            "id": str(appointment.id),
            "subject_id": str(appointment.subject_id),
            "professional_id": str(appointment.professional_id),
            "created_by_admin_id": str(appointment.created_by_admin_id) if appointment.created_by_admin_id else None,
            "starts_at": appointment.starts_at.isoformat() if appointment.starts_at else None,
            "ends_at": appointment.ends_at.isoformat() if appointment.ends_at else None,
            "status": appointment.status,
            "source": appointment.source,
            "title": appointment.title,
            "location": appointment.location,
            "notes": appointment.notes,
            "extra_data": appointment.extra_data or {},
            "created_at": appointment.created_at.isoformat() if appointment.created_at else None,
            "updated_at": appointment.updated_at.isoformat() if appointment.updated_at else None,
        }

    @staticmethod
    def serialize_visit_report(visit_report: CRMVisitReport) -> dict:
        return {
            "id": str(visit_report.id),
            "subject_id": str(visit_report.subject_id),
            "professional_id": str(visit_report.professional_id),
            "appointment_id": str(visit_report.appointment_id) if visit_report.appointment_id else None,
            "created_by_admin_id": str(visit_report.created_by_admin_id) if visit_report.created_by_admin_id else None,
            "occurred_at": visit_report.occurred_at.isoformat() if visit_report.occurred_at else None,
            "duration_minutes": visit_report.duration_minutes,
            "reason": visit_report.reason,
            "summary": visit_report.summary,
            "findings": visit_report.findings,
            "actions_taken": visit_report.actions_taken,
            "next_steps": visit_report.next_steps,
            "outcome": visit_report.outcome,
            "notes": visit_report.notes,
            "extra_data": visit_report.extra_data or {},
            "created_at": visit_report.created_at.isoformat() if visit_report.created_at else None,
        }

    @staticmethod
    async def build_subject_timeline(
        db: AsyncSession,
        tenant_id: uuid.UUID,
        file_id: uuid.UUID,
    ) -> dict:
        client_file = await CRMService.get_client_file_or_404(db, tenant_id, file_id)

        appointments_result = await db.execute(
            select(CRMAppointment).where(
                CRMAppointment.tenant_id == tenant_id,
                CRMAppointment.subject_id == file_id,
            ).order_by(CRMAppointment.starts_at.desc())
        )
        appointments = appointments_result.scalars().all()

        reports_result = await db.execute(
            select(CRMVisitReport).where(
                CRMVisitReport.tenant_id == tenant_id,
                CRMVisitReport.subject_id == file_id,
            ).order_by(CRMVisitReport.occurred_at.desc())
        )
        reports = reports_result.scalars().all()

        timeline = []
        for appointment in appointments:
            timeline.append(
                {
                    "type": "appointment",
                    "occurred_at": appointment.starts_at.isoformat(),
                    "data": CRMService.serialize_appointment(appointment),
                }
            )

        for report in reports:
            timeline.append(
                {
                    "type": "visit_report",
                    "occurred_at": report.occurred_at.isoformat(),
                    "data": CRMService.serialize_visit_report(report),
                }
            )

        timeline.sort(key=lambda item: item["occurred_at"], reverse=True)

        return {
            "subject": CRMService.serialize_client_file(client_file),
            "timeline": timeline,
        }
