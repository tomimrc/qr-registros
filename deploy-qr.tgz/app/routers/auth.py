# app/routers/auth.py

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, EmailStr
from app.database import get_db
from app.models.admin import Admin
from app.models.tenant import Tenant
from app.core.security import hash_password, verify_password, create_access_token
from app.core.dependencies import get_current_admin
from datetime import datetime, timezone
import uuid

router = APIRouter()


# =============================================
# SCHEMAS (forma de los datos que entran/salen)
# =============================================
class RegisterRequest(BaseModel):
    email: str
    password: str
    nombre: str
    tenant_id: uuid.UUID


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    admin_name: str
    tenant_id: str
    must_change_password: bool = False


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


# =============================================
# REGISTRO DE ADMIN
# =============================================
@router.post("/register", response_model=TokenResponse)
async def register_admin(
    data: RegisterRequest,
    db: AsyncSession = Depends(get_db)
):
    # Verificar que el tenant existe
    tenant = await db.get(Tenant, data.tenant_id)
    if not tenant or not tenant.is_active:
        raise HTTPException(status_code=404, detail="Empresa no encontrada.")

    # Verificar que el email no esté en uso
    existing = await db.execute(select(Admin).where(Admin.email == data.email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="El email ya está registrado.")

    # Crear admin con password hasheado
    admin = Admin(
        tenant_id=data.tenant_id,
        email=data.email,
        hashed_password=hash_password(data.password),
        nombre=data.nombre,
    )
    db.add(admin)
    await db.commit()

    # Usar create_access_token para el dashboard (JWT)
    token = create_access_token({"sub": str(admin.id), "tenant_id": str(admin.tenant_id)})
    return TokenResponse(
        access_token=token,
        admin_name=admin.nombre,
        tenant_id=str(admin.tenant_id),
        must_change_password=admin.must_change_password,
    )


# =============================================
# LOGIN
# =============================================
@router.post("/login", response_model=TokenResponse)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    # Buscar admin por email
    result = await db.execute(select(Admin).where(Admin.email == form_data.username))
    admin = result.scalar_one_or_none()

    # Verificar credenciales
    if not admin or not verify_password(form_data.password, admin.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email o contraseña incorrectos"
        )

    if not admin.is_active:
        raise HTTPException(status_code=403, detail="Cuenta desactivada.")

    # Usar create_access_token para el dashboard (JWT)
    token = create_access_token({"sub": str(admin.id), "tenant_id": str(admin.tenant_id)})
    return TokenResponse(
        access_token=token,
        admin_name=admin.nombre,
        tenant_id=str(admin.tenant_id),
        must_change_password=admin.must_change_password,
    )


# =============================================
# ENDPOINT PROTEGIDO DE PRUEBA
# =============================================
@router.get("/me")
async def get_me(admin: Admin = Depends(get_current_admin)):
    """Devuelve info del admin logueado. Útil para verificar el token."""
    return {
        "id": str(admin.id),
        "email": admin.email,
        "nombre": admin.nombre,
        "tenant_id": str(admin.tenant_id),
        "must_change_password": admin.must_change_password,
    }


@router.post("/change-password")
async def change_password(
    payload: ChangePasswordRequest,
    admin: Admin = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    if not verify_password(payload.current_password, admin.hashed_password):
        raise HTTPException(status_code=400, detail="La contraseña actual es incorrecta")

    if len(payload.new_password) < 8:
        raise HTTPException(status_code=400, detail="La nueva contraseña debe tener al menos 8 caracteres")

    admin.hashed_password = hash_password(payload.new_password)
    admin.must_change_password = False
    admin.password_changed_at = datetime.now(timezone.utc)
    await db.flush()

    return {"ok": True}